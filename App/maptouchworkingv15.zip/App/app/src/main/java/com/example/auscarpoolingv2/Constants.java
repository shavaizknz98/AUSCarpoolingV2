package com.example.auscarpoolingv2;

public class Constants {
    public static final int PERMISSIONS_REQUEST_ENABLE_GPS = 100;
    public static final int PERMISSIONS_REQUEST_ACCESS_FINE_LOCATION = 200;
    public static final int ERROR_DIALOG_REQUEST = 666;
}
