package com.example.auscarpoolingv2;

public class Users {

    private String name;
    private String phonenum;

    public String getName() {
        return name;
    }


    public String getPhonenum() {
        return phonenum;
    }

    public void setPhonenum(String phonenum) {
        this.phonenum = phonenum;
    }
    public void setName(String name) {
        this.name = name;
    }
}
